// Copyright Epic Games, Inc. All Rights Reserved.

#include "FaceAttBPLibrary.h"
#include "FaceAtt.h"

UFaceAttBPLibrary::UFaceAttBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

float UFaceAttBPLibrary::FaceAttSampleFunction(float Param)
{
	return -1;
}

